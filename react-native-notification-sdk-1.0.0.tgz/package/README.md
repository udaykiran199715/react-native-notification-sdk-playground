# React Native Notification SDK

<p align="center">
  <img src="./assets/logo.png" width="180" alt="Omnics Technologies Logo"/>
</p>

<p align="center">
A complete Push Notification SDK for React Native with built-in support for Firebase Cloud Messaging (FCM), Notifee, React Native CLI, and Expo Development Builds.
</p>

---

## Features

- 🚀 Simple SDK initialization
- 🔔 Local Notifications
- ☁️ Firebase Cloud Messaging (FCM)
- 📅 Scheduled Notifications
- 🎯 Notification Actions
- 📲 Notification Open Events
- 🗑 Notification Dismiss Events
- 🔄 Automatic Token Refresh Handling
- 🔐 Permission Management
- 📡 Background Notification Handling
- 📥 Foreground Notification Handling
- 🏗 Android Notification Channels
- 🍎 iOS Notification Categories
- 📱 React Native CLI Support
- ⚡ Expo Development Build Support
- 🧩 Built on Firebase Messaging + Notifee
- 🛠 TypeScript Support
- 🎯 Strongly Typed APIs
- 📖 Comprehensive Event System

---

# Why use this SDK?

Integrating Firebase Cloud Messaging and Notifee manually requires configuring multiple native modules, handling permissions, creating notification channels, managing foreground and background events, and dealing with platform-specific APIs.

This SDK abstracts those complexities into a single, easy-to-use API while still exposing advanced capabilities when needed.

---

# Supported Platforms

| Platform                | Supported |
| ----------------------- | --------- |
| Android                 | ✅        |
| iOS                     | ✅        |
| React Native CLI        | ✅        |
| Expo Development Builds | ✅        |
| Expo Go                 | ❌        |

> **Expo Go is not supported** because Firebase Messaging and Notifee require native native modules that are unavailable in Expo Go.

---

# Compatibility

| Dependency                       | Version                    |
| -------------------------------- | -------------------------- |
| React Native                     | >= 0.80                    |
| React                            | >= 19                      |
| Expo SDK                         | >= 53 (Development Builds) |
| @react-native-firebase/app       | >= 24                      |
| @react-native-firebase/messaging | >= 24                      |
| @notifee/react-native            | >= 9                       |

---

# Installation

## npm

```bash
npm install react-native-notification-sdk
```

## yarn

```bash
yarn add react-native-notification-sdk
```

## pnpm

```bash
pnpm add react-native-notification-sdk
```

---

# Install Peer Dependencies

The SDK relies on Firebase Messaging and Notifee.

Install them using your preferred package manager.

### npm

```bash
npm install @react-native-firebase/app
npm install @react-native-firebase/messaging
npm install @notifee/react-native
```

### yarn

```bash
yarn add @react-native-firebase/app
yarn add @react-native-firebase/messaging
yarn add @notifee/react-native
```

### pnpm

```bash
pnpm add @react-native-firebase/app
pnpm add @react-native-firebase/messaging
pnpm add @notifee/react-native
```

---

# React Native CLI Setup

## Android

Nothing additional is required.

React Native's autolinking will automatically link Firebase and Notifee.

## iOS

After installing dependencies:

```bash
cd ios
pod install
```

---

# Expo Development Build Setup

Add the following plugins to your `app.json`.

```json
{
  "expo": {
    "plugins": [
      "@react-native-firebase/app",
      "@react-native-firebase/messaging",
      "react-native-notification-sdk/plugins"
    ]
  }
}
```

Generate native projects:

```bash
npx expo prebuild --clean
```

Run Android:

```bash
npx expo run:android
```

Run iOS:

```bash
npx expo run:ios
```

---

# Firebase Setup

Before using the SDK, you must configure a Firebase project.

---

## Step 1 – Create Firebase Project

1. Open Firebase Console.
2. Click **Create Project**.
3. Enter your project name.
4. Continue through the wizard.
5. Finish project creation.

---

## Step 2 – Register Android App

Inside Firebase:

**Project Settings**

↓

**General**

↓

**Add App**

↓

**Android**

Enter:

- Android Package Name
- App Nickname (optional)

Example:

```
com.example.myapp
```

> **Important**

The package name entered here **must exactly match** the package name used in your Android application.

If it does not match, Gradle will fail with:

```
No matching client found for package name
```

---

## Step 3 – Download google-services.json

Firebase will generate:

```
google-services.json
```

Copy it to:

```
android/app/google-services.json
```

---

## Step 4 – Register iOS App

Again in Firebase:

**Add App**

↓

**iOS**

Enter:

Bundle Identifier

Example:

```
com.example.myapp
```

Again, this **must exactly match** your Xcode Bundle Identifier.

---

## Step 5 – Download GoogleService-Info.plist

Firebase generates:

```
GoogleService-Info.plist
```

Add it to your iOS project root.

For Expo:

```
GoogleService-Info.plist
```

should be referenced in:

```json
{
  "expo": {
    "ios": {
      "googleServicesFile": "./GoogleService-Info.plist"
    }
  }
}
```

---

# Configuring APNs (iOS Push Notifications)

Apple devices receive notifications through the **Apple Push Notification service (APNs)**.

Without APNs, Firebase Cloud Messaging cannot deliver notifications to iOS devices.

---

## Step 1 – Apple Developer Account

Log in to:

https://developer.apple.com

Open:

Certificates, Identifiers & Profiles

---

## Step 2 – Create or Select an App ID

Open **Identifiers**.

Select your application.

Enable:

- Push Notifications

Save the changes.

---

## Step 3 – Create an APNs Authentication Key

Navigate to:

Keys

↓

Create a new key.

Enable:

**Apple Push Notifications service (APNs)**

Download the generated `.p8` file.

> **Important:** Apple allows the `.p8` key to be downloaded only once. Store it securely.

Record the following values:

- Key ID
- Team ID

---

## Step 4 – Upload APNs Key to Firebase

Open Firebase Console.

Navigate to:

Project Settings

↓

Cloud Messaging

↓

Apple App Configuration

Upload:

- APNs Authentication Key (`.p8`)
- Key ID
- Team ID

Click **Save**.

---

## Step 5 – Enable Capabilities in Xcode

Open your iOS project in Xcode.

Select your target.

Open:

Signing & Capabilities

Enable:

- Push Notifications
- Background Modes

Inside Background Modes enable:

- Remote Notifications

---

# Notification Flow

Android

```
Server
   ↓
Firebase Cloud Messaging
   ↓
Android Device
   ↓
Notification SDK
```

iOS

```
Server
   ↓
Firebase Cloud Messaging
   ↓
Apple Push Notification Service (APNs)
   ↓
iPhone
   ↓
Notification SDK
```

---

# Project Ready

After completing the above steps:

✅ Firebase configured

✅ Android configured

✅ iOS configured

✅ Expo configured (if applicable)

You are now ready to initialize the Notification SDK.

➡️ Continue to **Part 2 – SDK Initialization & Configuration**

# SDK Initialization & Configuration

After completing the native platform setup, initialize the SDK when your application starts.

Typically, this is done inside your root component (`App.tsx`) or your application's entry point.

---

# Basic Initialization

```tsx
import Notifications from "react-native-notification-sdk";

await Notifications.initialize({
  debug: true,
});
```

---

# Production Initialization

```tsx
import Notifications from "react-native-notification-sdk";

await Notifications.initialize({
  debug: false,

  foreground: {
    displayNotifications: true,
  },

  background: {
    displayNotifications: true,
  },
});
```

---

# Advanced Initialization

```tsx
import Notifications from "react-native-notification-sdk";

await Notifications.initialize({
  debug: true,

  foreground: {
    displayNotifications: true,
  },

  background: {
    displayNotifications: true,
  },

  channels: [
    {
      id: "default",
      name: "Default Notifications",
      importance: "high",
    },

    {
      id: "orders",
      name: "Orders",
      importance: "high",
    },

    {
      id: "marketing",
      name: "Marketing",
      importance: "default",
    },
  ],
});
```

---

# Initialize Only Once

The SDK is designed as a singleton.

Calling:

```tsx
await Notifications.initialize(...)
```

multiple times is safe.

Subsequent calls are ignored after the SDK has been initialized.

---

# Configuration Reference

## debug

Enables SDK logs.

```tsx
debug: true;
```

Default

```tsx
false;
```

When enabled you'll see logs such as:

```
[NotificationSDK] Initializing SDK...
[NotificationSDK] Firebase initialized
[NotificationSDK] Token Generated
[NotificationSDK] Notification Received
```

---

# foreground

Automatically display notifications received while the application is open.

```tsx
foreground: {
  displayNotifications: true;
}
```

Default

```tsx
false;
```

When disabled, you'll still receive the event:

```tsx
Notifications.on("notificationReceived", ...)
```

and can display your own UI.

---

# background

Automatically display background **data** notifications.

```tsx
background: {
  displayNotifications: true;
}
```

Default

```tsx
true;
```

If disabled, only your registered background handler will execute.

---

# channels

Configure Android notification channels.

Example:

```tsx
channels: [
  {
    id: "orders",
    name: "Orders",
    importance: "high",
  },
];
```

If omitted, the SDK automatically creates:

| Property   | Value   |
| ---------- | ------- |
| ID         | default |
| Name       | Default |
| Importance | High    |

---

# iOS Configuration

Automatically request notification permission during initialization.

```tsx
ios: {
  requestPermissionOnLaunch: true;
}
```

Default

```tsx
false;
```

---

# Permission Management

Push notifications require user permission.

---

## Request Permission

```tsx
const status = await Notifications.requestPermission();

console.log(status);
```

Possible values:

| Status            |
| ----------------- |
| granted           |
| denied            |
| blocked           |
| provisional (iOS) |

---

## Check Current Permission

```tsx
const status = await Notifications.getPermissionStatus();
```

Useful for determining whether permission has already been granted.

---

# Recommended Permission Flow

```tsx
await Notifications.initialize({
  debug: true,
});

const permission = await Notifications.requestPermission();

if (permission === "granted") {
  const token = await Notifications.getToken();

  console.log(token);
}
```

---

# FCM Token Management

The Firebase Cloud Messaging token uniquely identifies the device.

This token should usually be sent to your backend server.

---

## Get Device Token

```tsx
const token = await Notifications.getToken();

console.log(token);
```

Example:

```
eVx9s8w.......
```

---

## Delete Token

Deletes the current FCM token.

```tsx
await Notifications.deleteToken();
```

This is useful during logout.

---

# Token Refresh

Firebase may rotate tokens.

Listen for updates.

```tsx
Notifications.on("tokenRefresh", ({ token }) => {
  console.log(token);
});
```

Whenever Firebase issues a new token, update your backend.

---

# SDK Lifecycle

## Destroy SDK

Destroy all listeners.

```tsx
Notifications.destroy();
```

This removes:

- Firebase listeners
- Event listeners
- Internal SDK state

Normally this method is **not** required unless you're intentionally shutting down the SDK.

---

# Common Initialization Example

```tsx
import { useEffect } from "react";
import Notifications from "react-native-notification-sdk";

export default function App() {
  useEffect(() => {
    async function initialize() {
      await Notifications.initialize({
        debug: true,

        foreground: {
          displayNotifications: true,
        },

        background: {
          displayNotifications: true,
        },
      });

      const permission = await Notifications.requestPermission();

      if (permission === "granted") {
        const token = await Notifications.getToken();

        console.log(token);
      }
    }

    initialize();
  }, []);

  return null;
}
```

---

# Best Practices

✅ Initialize the SDK once during application startup.

✅ Request notification permission only when appropriate for your user experience.

✅ Store the FCM token on your backend.

✅ Update the stored token whenever the `tokenRefresh` event is emitted.

✅ Keep `debug` disabled in production builds.

---

# What's Next?

Now that the SDK is initialized, the next section covers:

- Local Notifications
- Scheduled Notifications
- Notification Channels
- Notification Actions
- Android & iOS Notification Options

➡️ Continue to **Part 3 – Notifications**

# Notifications

The SDK supports:

- Local Notifications
- Scheduled Notifications
- Notification Actions
- Android Notification Channels
- Android & iOS specific notification options

---

# Display a Local Notification

Display a notification immediately.

```tsx
import Notifications from "react-native-notification-sdk";

await Notifications.displayNotification({
  title: "Welcome 👋",
  body: "Thanks for installing the Notification SDK.",
});
```

---

# Complete Notification Example

```tsx
await Notifications.displayNotification({
  title: "Order Received",
  body: "Your order has been placed successfully.",

  subtitle: "Order #1024",

  data: {
    orderId: "1024",
    screen: "orders",
  },

  android: {
    channelId: "orders",
    color: "#1976D2",
    autoCancel: true,
    pressActionId: "default",
  },

  ios: {
    badge: 1,
    sound: "default",
  },
});
```

---

# DisplayNotification Interface

## id

Optional notification identifier.

```tsx
id: "notification_1";
```

If omitted, Notifee automatically generates one.

---

## title

Notification title.

```tsx
title: "Hello";
```

Required.

---

## body

Notification body.

```tsx
body: "Welcome to Notification SDK";
```

Required.

---

## subtitle

Optional subtitle.

```tsx
subtitle: "Today's Updates";
```

---

## data

Attach custom key/value data.

```tsx
data: {
    screen: "orders",
    orderId: "1001"
}
```

Retrieve this data when the notification is opened.

---

# Android Options

```tsx
android: {
    channelId: "orders",
    pressActionId: "default",
    smallIcon: "ic_notification",
    largeIcon: "https://example.com/logo.png",
    color: "#2196F3",
    autoCancel: true
}
```

---

## channelId

Notification channel.

```tsx
channelId: "orders";
```

If omitted, the SDK uses the default channel.

---

## pressActionId

Press action identifier.

```tsx
pressActionId: "default";
```

---

## smallIcon

Android notification icon.

```tsx
smallIcon: "ic_notification";
```

This icon must exist inside:

```
android/app/src/main/res/drawable
```

---

## largeIcon

Large notification icon.

Supports:

- Remote URL
- Local resource

Example:

```tsx
largeIcon: "https://example.com/logo.png";
```

---

## color

Notification accent color.

```tsx
color: "#FF5722";
```

---

## autoCancel

Automatically remove the notification when tapped.

```tsx
autoCancel: true;
```

Default

```tsx
true;
```

---

# iOS Options

```tsx
ios: {
    badge: 5,
    sound: "default",
    categoryId: "ORDER_ACTIONS"
}
```

---

## badge

Application badge count.

```tsx
badge: 10;
```

---

## sound

Notification sound.

```tsx
sound: "default";
```

or

```tsx
sound: "notification.wav";
```

---

## categoryId

Notification category identifier.

Useful for notification actions on iOS.

---

# Notification Actions

Interactive notification buttons.

Example:

```tsx
await Notifications.displayNotification({
  title: "Incoming Order",
  body: "Accept this order?",

  actions: [
    {
      id: "accept",
      title: "Accept",
    },

    {
      id: "reject",
      title: "Reject",
      destructive: true,
    },
  ],
});
```

---

# NotificationAction Interface

```tsx
{
    id: string
    title: string
    launchActivity?: "default"
    destructive?: boolean
    input?: boolean
}
```

---

## id

Unique action identifier.

```tsx
id: "accept";
```

---

## title

Button text.

```tsx
title: "Accept";
```

---

## destructive

Android only.

Displays the action as destructive.

```tsx
destructive: true;
```

---

## launchActivity

Launches the application.

```tsx
launchActivity: "default";
```

---

## input

Allows inline reply.

```tsx
input: true;
```

---

# Listen for Notification Actions

```tsx
Notifications.on(
  "notificationActionPressed",

  ({ notification, actionId, input }) => {
    console.log(actionId);

    console.log(input);
  },
);
```

---

# Scheduled Notifications

Schedule notifications to appear later.

---

## Timestamp Trigger

```tsx
const id = await Notifications.scheduleNotification({
  title: "Meeting",

  body: "Standup starts in 10 minutes",

  trigger: {
    type: "timestamp",
    timestamp: Date.now() + 600000,
  },
});
```

Returns:

```tsx
notification - id;
```

---

# ScheduledNotification Interface

```tsx
{
    ...DisplayNotification

    trigger: NotificationTrigger
}
```

---

# NotificationTrigger

```tsx
{
  type: "timestamp";
  timestamp: number;
}
```

---

# Cancel Scheduled Notification

```tsx
await Notifications.cancelScheduledNotification(id);
```

---

# Cancel All Scheduled Notifications

```tsx
await Notifications.cancelAllScheduledNotifications();
```

---

# Get Scheduled Notifications

```tsx
const notifications = await Notifications.getScheduledNotifications();

console.log(notifications);
```

---

# Cancel a Displayed Notification

```tsx
await Notifications.cancelNotification(notificationId);
```

---

# Cancel All Notifications

```tsx
await Notifications.cancelAllNotifications();
```

---

# Android Notification Channels

Channels allow Android users to manage notification behavior.

Example:

```tsx
await Notifications.initialize({
  channels: [
    {
      id: "orders",
      name: "Orders",
      importance: "high",
    },

    {
      id: "marketing",
      name: "Marketing",
      importance: "default",
    },
  ],
});
```

---

# NotificationChannel Interface

```tsx
{
    id: string

    name: string

    description?: string

    importance?:
        | "none"
        | "min"
        | "low"
        | "default"
        | "high"
        | "max"
}
```

---

# Importance Levels

| Value   | Description      |
| ------- | ---------------- |
| none    | Disabled         |
| min     | Silent           |
| low     | Low Priority     |
| default | Standard         |
| high    | High Priority    |
| max     | Maximum Priority |

---

# Best Practices

✅ Use notification channels to categorize notifications.

✅ Use custom `data` instead of parsing notification text.

✅ Keep notification titles concise.

✅ Provide meaningful action buttons.

✅ Use scheduled notifications for reminders instead of background timers.

✅ Use separate channels for marketing and transactional notifications.

---

# What's Next?

The next section covers:

- Notification Events
- Foreground Notifications
- Background Notifications
- Deep Linking
- Notification Lifecycle
- Event System

➡️ Continue to **Part 4 – Events & Background Handling**

# Events & Background Handling

The SDK exposes a strongly typed event system for listening to notification lifecycle events.

Events can be subscribed to using:

```tsx
Notifications.on(eventName, listener);
```

and removed using:

```tsx
Notifications.off(eventName, listener);
```

The `on()` method also returns an unsubscribe function.

```tsx
const unsubscribe = Notifications.on(
  "notificationReceived",
  ({ notification }) => {
    console.log(notification);
  },
);

unsubscribe();
```

---

# Event Lifecycle

```
FCM Notification
        │
        ▼
Firebase Messaging
        │
        ▼
Notification SDK
        │
        ├──────── notificationReceived
        │
        ├──────── notificationOpened
        │
        ├──────── notificationDismissed
        │
        ├──────── notificationActionPressed
        │
        ├──────── tokenRefresh
        │
        └──────── permissionChanged
```

---

# Available Events

| Event                     | Description                                |
| ------------------------- | ------------------------------------------ |
| initialized               | SDK initialization completed               |
| tokenGenerated            | Initial FCM token generated                |
| tokenRefresh              | Firebase refreshed the FCM token           |
| notificationReceived      | Notification received while app is running |
| notificationOpened        | User tapped a notification                 |
| notificationDismissed     | User dismissed a notification              |
| notificationActionPressed | User pressed a notification action button  |
| permissionChanged         | Notification permission changed            |

---

# initialized

Triggered once the SDK has finished initialization.

```tsx
Notifications.on("initialized", () => {
  console.log("SDK Ready");
});
```

---

# tokenGenerated

Called after requesting the initial FCM token.

```tsx
Notifications.on("tokenGenerated", ({ token }) => {
  console.log(token);
});
```

Payload

```ts
{
  token: string;
}
```

---

# tokenRefresh

Firebase may periodically rotate device tokens.

Always update your backend.

```tsx
Notifications.on("tokenRefresh", ({ token }) => {
  await api.updateToken(token);
});
```

Payload

```ts
{
  token: string;
}
```

---

# notificationReceived

Triggered whenever a notification is received while the application is in the foreground.

```tsx
Notifications.on(
  "notificationReceived",

  ({ notification }) => {
    console.log(notification);
  },
);
```

Payload

```ts
{
  notification: NotificationPayload;
}
```

---

# notificationOpened

Triggered when the user taps a notification.

```tsx
Notifications.on(
  "notificationOpened",

  ({ notification }) => {
    console.log(notification.data);
  },
);
```

Typical usage

```tsx
Notifications.on(
  "notificationOpened",

  ({ notification }) => {
    if (notification.data?.screen === "orders") {
      navigation.navigate("Orders");
    }
  },
);
```

---

# notificationDismissed

Triggered when a notification is dismissed by the user.

```tsx
Notifications.on(
  "notificationDismissed",

  ({ notification }) => {
    console.log(notification);
  },
);
```

Useful for analytics.

---

# notificationActionPressed

Triggered when an action button is pressed.

```tsx
Notifications.on(
  "notificationActionPressed",

  ({ notification, actionId, input }) => {
    switch (actionId) {
      case "accept":
        console.log("Accepted");

        break;

      case "reject":
        console.log("Rejected");

        break;
    }
  },
);
```

Payload

```ts
{
    notification: NotificationPayload
    actionId: string
    input?: string
}
```

---

# permissionChanged

Triggered whenever notification permission changes.

```tsx
Notifications.on(
  "permissionChanged",

  ({ status }) => {
    console.log(status);
  },
);
```

Payload

```ts
{
  status: PermissionStatus;
}
```

Possible values

- granted
- denied
- blocked
- provisional (iOS)

---

# Background Notifications

Background messages are delivered when the application is:

- Backgrounded
- Swiped away (Android)
- Terminated (Android data messages)
- Inactive

Register a background handler **before your application starts**.

Example (`index.js`)

```tsx
import Notifications from "react-native-notification-sdk";

Notifications.registerBackgroundHandler(async (notification) => {
  console.log("Background Notification");

  console.log(notification);
});
```

Only one background handler should be registered.

---

# Automatic Background Display

By default

```tsx
background: {
  displayNotifications: true;
}
```

The SDK automatically converts Firebase data messages into local notifications using Notifee.

Disable automatic display

```tsx
await Notifications.initialize({
  background: {
    displayNotifications: false,
  },
});
```

Now only your background handler will execute.

---

# Foreground Notifications

Normally Android and iOS do **not** display FCM notifications while the application is open.

Enable automatic display

```tsx
await Notifications.initialize({
  foreground: {
    displayNotifications: true,
  },
});
```

Now incoming foreground messages are automatically displayed using Notifee.

Disable automatic display

```tsx
foreground: {
  displayNotifications: false;
}
```

Then manually display notifications.

```tsx
Notifications.on(
  "notificationReceived",

  async ({ notification }) => {
    await Notifications.displayNotification({
      title: notification.title,

      body: notification.body,

      data: notification.data,
    });
  },
);
```

---

# Notification Payload

Every notification received by the SDK is mapped into a common structure.

```ts
interface NotificationPayload {
  id?: string;

  title?: string;

  body?: string;

  subtitle?: string;

  data?: Record<string, string>;

  imageUrl?: string;

  sentTime?: number;

  from?: string;
}
```

This provides a consistent payload across Android and iOS.

---

# Deep Linking

Use notification data to navigate users to a specific screen.

Example payload

```json
{
  "screen": "orders",
  "orderId": "1001"
}
```

Handle navigation

```tsx
Notifications.on(
  "notificationOpened",

  ({ notification }) => {
    const screen = notification.data?.screen;

    if (screen === "orders") {
      navigation.navigate("Orders", {
        id: notification.data?.orderId,
      });
    }
  },
);
```

---

# Complete Event Registration Example

```tsx
useEffect(() => {
  const subscriptions = [
    Notifications.on("initialized", () => {
      console.log("SDK Ready");
    }),

    Notifications.on("tokenGenerated", ({ token }) => {
      console.log(token);
    }),

    Notifications.on("tokenRefresh", ({ token }) => {
      console.log(token);
    }),

    Notifications.on("notificationReceived", ({ notification }) => {
      console.log(notification);
    }),

    Notifications.on("notificationOpened", ({ notification }) => {
      console.log(notification);
    }),

    Notifications.on("notificationDismissed", ({ notification }) => {
      console.log(notification);
    }),

    Notifications.on("notificationActionPressed", ({ actionId }) => {
      console.log(actionId);
    }),

    Notifications.on("permissionChanged", ({ status }) => {
      console.log(status);
    }),
  ];

  return () => {
    subscriptions.forEach((unsubscribe) => unsubscribe());
  };
}, []);
```

---

# Best Practices

✅ Register listeners once during application startup.

✅ Always unsubscribe listeners when appropriate.

✅ Update your backend whenever the FCM token changes.

✅ Use notification `data` for navigation instead of parsing titles or bodies.

✅ Register the background handler before rendering your application.

✅ Keep background handlers lightweight—perform only essential work.

---

# Common Notification Flows

### Foreground

```
Server
   │
   ▼
Firebase
   │
   ▼
notificationReceived
   │
   ▼
Display Notification (optional)
```

### Background

```
Server
   │
   ▼
Firebase
   │
   ▼
Background Handler
   │
   ▼
Display Notification (automatic or manual)
```

### User Interaction

```
Notification
     │
     ▼
User taps notification
     │
     ▼
notificationOpened
     │
     ▼
Navigate to screen
```

---

# What's Next?

The next section contains the **complete API Reference**, including:

- Every public method
- Every interface
- Every type
- Error classes
- Validators
- Complete code examples

➡️ Continue to **Part 5 – API Reference**

# API Reference

This section documents every public method exposed by the SDK.

Import the SDK:

```tsx
import Notifications from "react-native-notification-sdk";
```

---

# initialize()

Initializes the Notification SDK.

Must be called before using any other SDK method.

## Signature

```ts
initialize(config: NotificationConfig): Promise<void>
```

## Example

```tsx
await Notifications.initialize({
  debug: true,

  foreground: {
    displayNotifications: true,
  },

  background: {
    displayNotifications: true,
  },
});
```

## Parameters

| Property | Type               | Required | Description       |
| -------- | ------------------ | -------- | ----------------- |
| config   | NotificationConfig | ✅       | SDK configuration |

---

# requestPermission()

Requests notification permission.

## Signature

```ts
requestPermission(): Promise<PermissionStatus>
```

## Example

```tsx
const status = await Notifications.requestPermission();
```

Returns

```ts
PermissionStatus;
```

Possible values

- granted
- denied
- blocked
- provisional (iOS)

---

# getPermissionStatus()

Returns the current notification permission.

## Signature

```ts
getPermissionStatus(): Promise<PermissionStatus>
```

Example

```tsx
const permission = await Notifications.getPermissionStatus();
```

---

# getToken()

Returns the Firebase Cloud Messaging token.

## Signature

```ts
getToken(): Promise<string>
```

Example

```tsx
const token = await Notifications.getToken();
```

---

# deleteToken()

Deletes the FCM token.

Useful when logging out.

## Signature

```ts
deleteToken(): Promise<void>
```

Example

```tsx
await Notifications.deleteToken();
```

---

# displayNotification()

Displays a local notification.

## Signature

```ts
displayNotification(
    notification: DisplayNotification
): Promise<void>
```

Example

```tsx
await Notifications.displayNotification({
  title: "Hello",

  body: "Notification SDK",
});
```

---

# scheduleNotification()

Schedules a local notification.

## Signature

```ts
scheduleNotification(
    notification: ScheduledNotification
): Promise<string>
```

Returns

Notification ID

Example

```tsx
const id = await Notifications.scheduleNotification({
  title: "Meeting",

  body: "Standup",

  trigger: {
    type: "timestamp",

    timestamp: Date.now() + 60000,
  },
});
```

---

# cancelNotification()

Cancels a displayed notification.

## Signature

```ts
cancelNotification(
    id: string
): Promise<void>
```

---

# cancelAllNotifications()

Removes all displayed notifications.

## Signature

```ts
cancelAllNotifications(): Promise<void>
```

---

# cancelScheduledNotification()

Cancels a scheduled notification.

## Signature

```ts
cancelScheduledNotification(
    id: string
): Promise<void>
```

---

# cancelAllScheduledNotifications()

Cancels every scheduled notification.

## Signature

```ts
cancelAllScheduledNotifications(): Promise<void>
```

---

# getScheduledNotifications()

Returns all scheduled notifications.

## Signature

```ts
getScheduledNotifications(): Promise<ScheduledNotification[]>
```

Example

```tsx
const notifications = await Notifications.getScheduledNotifications();
```

---

# registerBackgroundHandler()

Registers the Firebase background handler.

Only one handler should be registered.

Register before rendering the application.

## Signature

```ts
registerBackgroundHandler(
    handler:
        (
            notification: NotificationPayload
        ) => Promise<void>
): void
```

Example

```tsx
Notifications.registerBackgroundHandler(async (notification) => {
  console.log(notification);
});
```

---

# destroy()

Destroys the SDK.

Removes listeners and internal state.

Normally this is not required.

## Signature

```ts
destroy(): void
```

---

# on()

Registers an event listener.

Returns an unsubscribe function.

## Signature

```ts
on<K extends keyof NotificationEvents>(
    event: K,
    listener:
        (
            payload:
                NotificationEvents[K]
        ) => void
): () => void
```

Example

```tsx
const unsubscribe = Notifications.on(
  "notificationReceived",

  ({ notification }) => {
    console.log(notification);
  },
);
```

---

# off()

Removes an event listener.

## Signature

```ts
off<K extends keyof NotificationEvents>(
    event: K,
    listener:
        (
            payload:
                NotificationEvents[K]
        ) => void
): void
```

---

# NotificationConfig

```ts
interface NotificationConfig {
  debug?: boolean;

  foreground?: {
    displayNotifications?: boolean;
  };

  background?: {
    displayNotifications?: boolean;
  };

  ios?: {
    requestPermissionOnLaunch?: boolean;
  };

  channels?: NotificationChannel[];
}
```

---

# DisplayNotification

```ts
interface DisplayNotification {
  id?: string;

  title: string;

  body: string;

  subtitle?: string;

  data?: Record<string, string>;

  actions?: NotificationAction[];

  android?: AndroidNotificationOptions;

  ios?: IOSNotificationOptions;
}
```

---

# ScheduledNotification

```ts
interface ScheduledNotification extends DisplayNotification {
  trigger: NotificationTrigger;
}
```

---

# NotificationTrigger

```ts
interface NotificationTrigger {
  type: "timestamp";

  timestamp: number;
}
```

---

# NotificationAction

```ts
interface NotificationAction {
  id: string;

  title: string;

  launchActivity?: "default";

  destructive?: boolean;

  input?: boolean;
}
```

---

# NotificationChannel

```ts
interface NotificationChannel {
  id: string;

  name: string;

  description?: string;

  importance?: "none" | "min" | "low" | "default" | "high" | "max";
}
```

---

# AndroidNotificationOptions

```ts
interface AndroidNotificationOptions {
  channelId?: string;

  pressActionId?: string;

  smallIcon?: string;

  largeIcon?: string;

  color?: string;

  autoCancel?: boolean;
}
```

---

# IOSNotificationOptions

```ts
interface IOSNotificationOptions {
  badge?: number;

  sound?: string;

  categoryId?: string;
}
```

---

# NotificationPayload

```ts
interface NotificationPayload {
  id?: string;

  title?: string;

  body?: string;

  subtitle?: string;

  data?: Record<string, string>;

  imageUrl?: string;

  sentTime?: number;

  from?: string;
}
```

---

# PermissionStatus

```ts
type PermissionStatus = "granted" | "denied" | "blocked" | "provisional";
```

---

# Error Handling

The SDK may throw the following errors:

| Error                       | Description                             |
| --------------------------- | --------------------------------------- |
| SDKNotInitializedError      | SDK method called before initialization |
| FirebaseInitializationError | Firebase initialization failed          |
| NotifeeInitializationError  | Notifee initialization failed           |
| PermissionDeniedError       | Notification permission denied          |
| InvalidNotificationError    | Invalid notification payload            |

Example

```tsx
try {
  await Notifications.initialize({
    debug: true,
  });
} catch (error) {
  console.error(error);
}
```

---

# Validation

The SDK validates:

- Notification channels
- Display notifications
- Scheduled notifications
- Notification actions

Invalid payloads throw descriptive errors before reaching the native layer.

---

# Thread Safety

The SDK is implemented as a singleton.

- Multiple calls to `initialize()` are ignored after the first successful initialization.
- Event listeners are managed through an internal event bus.
- Native services are initialized only once.

---

# Best Practices

- Initialize the SDK once at app startup.
- Keep notification payloads lightweight.
- Store and update FCM tokens on your backend.
- Always unsubscribe event listeners when they are no longer needed.
- Use notification `data` for navigation rather than parsing titles or bodies.
- Register the background handler before the app renders.
- Disable `debug` in production.

---

# What's Next?

The final section covers:

- Troubleshooting
- Frequently Asked Questions (FAQ)
- Upgrade Guide
- Production Checklist
- Common Firebase Errors
- Common Expo Errors
- Common React Native Errors
- Security Recommendations
- Performance Recommendations
- License

➡️ Continue to **Part 6 – Troubleshooting & Production Guide**

# Troubleshooting & Production Guide

This section contains the most common issues encountered while integrating the Notification SDK and their solutions.

---

# Troubleshooting

## SDKNotInitializedError

### Error

```text
Notification SDK must be initialized before calling this method.
```

### Cause

A Notification SDK method was called before `initialize()`.

### Solution

Initialize the SDK before using any other API.

```tsx
await Notifications.initialize({
  debug: true,
});

const token = await Notifications.getToken();
```

---

## RNFBAppModule not found

### Error

```text
Native module RNFBAppModule not found.
```

### Cause

React Native Firebase is not properly linked.

### Solution (React Native CLI)

```bash
npm install @react-native-firebase/app
npm install @react-native-firebase/messaging

cd ios
pod install
```

### Solution (Expo)

```bash
npx expo prebuild --clean
npx expo run:android
```

---

## app.notifee:core:+ could not be found

### Error

```text
Could not find app.notifee:core:+
```

### Cause

The Notifee local Maven repository was not added to the Android project.

### Solution

If using Expo Development Builds:

- Ensure the SDK plugin is configured.

```json
{
  "expo": {
    "plugins": [
      "@react-native-firebase/app",
      "@react-native-firebase/messaging",
      "react-native-notification-sdk/plugins"
    ]
  }
}
```

Then regenerate native projects.

```bash
npx expo prebuild --clean
```

---

## No matching client found for package name

### Error

```text
No matching client found for package name
```

### Cause

The package name in `google-services.json` does not match the application's package name.

### Solution

Register the correct Android package in Firebase.

Download a new:

```text
google-services.json
```

Replace:

```text
android/app/google-services.json
```

---

## GoogleService-Info.plist not found

### Cause

The iOS Firebase configuration file is missing.

### Solution

Download the file from Firebase.

Reference it in Expo.

```json
{
  "expo": {
    "ios": {
      "googleServicesFile": "./GoogleService-Info.plist"
    }
  }
}
```

---

## Notifications not received on Android

Check the following:

- Google Play Services installed
- Internet connection
- Notification permission granted (Android 13+)
- Valid Firebase token
- Correct Firebase project

---

## Notifications not received on iOS

Verify:

- APNs Authentication Key uploaded
- Push Notifications capability enabled
- Background Modes enabled
- Remote Notifications enabled
- Correct Bundle Identifier
- Physical device (simulator cannot receive push notifications)

---

## Foreground notifications not displayed

By default, Firebase does not display notifications while the application is open.

Enable automatic display.

```tsx
await Notifications.initialize({
  foreground: {
    displayNotifications: true,
  },
});
```

---

## Background handler not called

Ensure:

```tsx
Notifications.registerBackgroundHandler(...)
```

is registered **before** rendering the application.

Only one background handler should exist.

---

## Scheduled notifications not appearing

Verify:

- Notification permission granted
- Device date and time correct
- Trigger timestamp is in the future

---

# Frequently Asked Questions

## Does this SDK support Expo Go?

No.

Firebase Messaging and Notifee require native modules that are unavailable in Expo Go.

Use an Expo Development Build.

---

## Does this SDK support React Native CLI?

Yes.

React Native CLI is fully supported.

---

## Does this SDK support Expo?

Yes.

Supported through Expo Development Builds.

---

## Do I need Notifee?

Yes.

Notifee is responsible for:

- Local notifications
- Scheduled notifications
- Notification actions
- Foreground notification display

---

## Do I need Firebase?

Yes.

Firebase Cloud Messaging is required for remote push notifications.

---

## Can I disable automatic notification display?

Yes.

Foreground

```tsx
foreground: {
  displayNotifications: false;
}
```

Background

```tsx
background: {
  displayNotifications: false;
}
```

---

## Can I display my own UI?

Yes.

Listen for:

```tsx
Notifications.on(
    "notificationReceived",
    ...
)
```

and display your own interface.

---

## Is initialization safe to call multiple times?

Yes.

The SDK ignores repeated calls after successful initialization.

---

## Does the SDK refresh tokens automatically?

Yes.

Listen for:

```tsx
Notifications.on("tokenRefresh");
```

and update your backend.

---

## Can I schedule notifications?

Yes.

```tsx
await Notifications.scheduleNotification(...)
```

---

## Can I cancel scheduled notifications?

Yes.

```tsx
await Notifications.cancelScheduledNotification(id);
```

or

```tsx
await Notifications.cancelAllScheduledNotifications();
```

---

## Can I deep link into my application?

Yes.

Use notification `data` inside:

```tsx
notificationOpened;
```

to navigate to a specific screen.

---

# Security Recommendations

- Never expose Firebase Server Keys in the client application.
- Store FCM tokens securely on your backend.
- Validate notification payloads on the server.
- Use HTTPS for all notification-related APIs.
- Remove FCM tokens when users log out.

---

# Performance Recommendations

- Initialize the SDK only once.
- Keep background handlers lightweight.
- Avoid large notification payloads.
- Use notification channels to organize notifications.
- Batch backend token updates when possible.

---

# Upgrade Guide

After upgrading the SDK:

### React Native CLI

```bash
npm install

cd ios
pod install
```

### Expo

```bash
npm install

npx expo prebuild --clean

npx expo run:android

npx expo run:ios
```

---

# Production Checklist

Before releasing your application:

## Firebase

- ✅ Firebase project created
- ✅ Android application registered
- ✅ iOS application registered
- ✅ SHA-1 uploaded (Android)
- ✅ SHA-256 uploaded (Android)
- ✅ APNs Authentication Key uploaded (iOS)

## Android

- ✅ `google-services.json` added
- ✅ Notification permission requested (Android 13+)
- ✅ Notification channels configured
- ✅ Small notification icon added

## iOS

- ✅ `GoogleService-Info.plist` added
- ✅ Push Notifications capability enabled
- ✅ Background Modes enabled
- ✅ Remote Notifications enabled

## SDK

- ✅ SDK initialized
- ✅ Background handler registered
- ✅ Foreground notifications configured
- ✅ Notification actions tested
- ✅ Scheduled notifications tested
- ✅ Token stored on backend
- ✅ Token refresh handling implemented

## Testing

- ✅ Android physical device tested
- ✅ iOS physical device tested
- ✅ Foreground notifications tested
- ✅ Background notifications tested
- ✅ Terminated app notifications tested
- ✅ Notification open events tested
- ✅ Notification action buttons tested

---

# Automatic Features

The SDK automatically:

- Initializes Firebase
- Initializes Notifee
- Creates Android notification channels
- Registers Firebase listeners
- Registers notification listeners
- Maps Firebase payloads to a unified notification payload
- Emits notification lifecycle events
- Generates and refreshes FCM tokens
- Displays foreground notifications (optional)
- Displays background data notifications (optional)

---

# License

MIT License

---

# Support

If you encounter issues:

1. Verify your Firebase configuration.
2. Verify Android package name and iOS bundle identifier.
3. Ensure native projects are rebuilt after configuration changes.
4. Review the troubleshooting section above before opening an issue.

---

# Thank You

Thank you for choosing **React Native Notification SDK**.

We hope this SDK helps you build reliable, scalable, and production-ready notification experiences with minimal setup while retaining the flexibility required for advanced notification workflows.

Happy coding! 🚀
