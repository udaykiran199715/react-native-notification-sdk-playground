const { withProjectBuildGradle } = require("@expo/config-plugins");

module.exports = function withAndroidGradle(config) {
  return withProjectBuildGradle(config, (config) => {
    let contents = config.modResults.contents;

    const repo = `maven { url("$rootDir/../node_modules/@notifee/react-native/android/libs") }`;

    if (contents.includes("@notifee/react-native/android/libs")) {
      return config;
    }

    contents = contents.replace(
      /(allprojects\s*\{\s*repositories\s*\{)/,
      `$1\n    ${repo}`,
    );

    config.modResults.contents = contents;

    return config;
  });
};
