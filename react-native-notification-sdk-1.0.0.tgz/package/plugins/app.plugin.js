const withAndroidMaven = require("./android/withMaven");
const withModularHeaders = require("./ios/withModularHeaders");
module.exports = function withNotificationSDK(config) {
  config = withAndroidMaven(config);
  config = withModularHeaders(config);
  return config;
};
