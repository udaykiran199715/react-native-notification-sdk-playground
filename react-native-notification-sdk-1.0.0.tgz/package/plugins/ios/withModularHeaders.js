const { withPodfile } = require("@expo/config-plugins");

const withModularHeaders = (config) => {
  return withPodfile(config, (config) => {
    const contents = config.modResults.contents;
    if (!contents.includes("use_modular_headers!")) {
      config.modResults.contents = contents.replace(
        /^(platform :ios.*\n)/m,
        `$1\nuse_modular_headers!\n`,
      );
    }
    return config;
  });
};

module.exports = withModularHeaders;
